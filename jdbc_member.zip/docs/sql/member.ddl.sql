

 -- ���̺� ����, not null ����

 create table members (
    member_id varchar2(30),
    member_pw varchar2(20) not null,
    member_name varchar2(20) not null,
    mobile char(13) not null,
    email varchar2(30) not null,
    entry_date char(10) not null,
    grade char(1) not null,
    mileage number(6),
    manager varchar2(20)
 );

-- ���� ���� �߰�

ALTER TABLE MEMBERS
ADD CONSTRAINT PK_memberid PRIMARY KEY(member_id);
ALTER TABLE MEMBERS
ADD CONSTRAINT UK_mobile unique(mobile);
ALTER TABLE MEMBERS
ADD CONSTRAINT UK_email unique(email);

-- �����ͻ���

insert into members 
values('user01', 'password01', 'ȫ�浿', '010-1234-1111', 'user01@work.com', '2017/05/10', 'G', 1000, null);
insert into members 
values('user02', 'password02', '������', '010-1234-1112', 'user02@work.com', '2017/05/11', 'G', 2000, null);
insert into members 
values('user03', 'password03', '�̼���', '010-1234-1113', 'user03@work.com', '2017/05/12', 'G', 3000, null);
insert into members 
values('suser01', 'password01', '������', '010-1111-1111', 'suser01@work.com', '2017/03/01', 'S', null, '���߱�');
insert into members 
values('suser02', 'password02', '������', '010-1111-1112', 'suser02@work.com', '2017/03/02', 'S', null, '������');
insert into members 
values('auser01', 'password01', '������', '010-1111-1234', 'auser01@work.com', '2017/04/21', 'A', null, null);

