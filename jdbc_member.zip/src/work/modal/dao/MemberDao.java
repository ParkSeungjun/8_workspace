package work.modal.dao;

/**
 * ## DAO(Data Access Object) Pattern
 * 1. driver loading
 * 2. db ���� ���� : url. user, password
 * => Connection ��ȯ �޼��� ����
 * => getConnection() : Connection
 * 3. sql ��ΰ��� Statement / PreparedStatement / Callablestatement
 * 4. sql ����
 * 5. ���ó��
 * 6. �ڿ����� :
 * 	=> close() �ߺ�����
 * 	=> cud : stmt, conn
 *  => r : rs, stmt, conn
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import work.model.dto.Member;



public class MemberDao {
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@127.0.0.1:1521:XE";
	private String user = "scott";
	private String password = "tiger";
	
	
	public MemberDao() {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("����(Driver�ε� ����) : " + e.getMessage());
		}
		
		try {
			
			Connection conn = getConnection();
			
			Statement stmt = conn.createStatement();
			
			String sql = "select * from dept";
					
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				int deptno = rs.getInt("deptno");
				String dname = rs.getString("dname");
				String loc = rs.getString("loc");
				
				System.out.println(deptno + ", " + dname + ", " + loc);
			}
			
			close(rs, stmt, conn);
	
		} catch(SQLException e) {
			e.printStackTrace();
			System.out.println("���� : " + e.getMessage());
		}
	}
	// Connection ��ȯ �޼��� ����
	public Connection getConnection() {
		try {
			return DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("����(DB���� �������) : " + e.getMessage());
		}
		return null;
	}
	
	// �ڿ����� �޼��� �ߺ����� ����(r)
		public void close(ResultSet rs, Statement stmt, Connection conn) {
			try {
				if(rs != null) {
					rs.close();	
				}
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("����(�ڿ���������) : " + e.getMessage());
			}
		}
	
	// �ڿ����� �޼��� �ߺ����� ����(cud)
	public void close(Statement stmt, Connection conn) {
			close(null, stmt, conn);
	}
	
	//��üȸ������
	public ArrayList<Member> selectList() {
		ArrayList<Member> tmp = new ArrayList<Member>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from members";
		
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			String memberId = null;
			String memberPw = null;
			String memberName = null;
			String mobile = null;
			String email = null;
			String entryDate = null;
			char grade = '\u0000';
			int mileage = 0;
			String manager = null;
			
			
			while(rs.next()) {
				
				memberId = rs.getString("member_id");
				memberPw = rs.getString("member_pw");
				memberName = rs.getString("member_name");
				mobile = rs.getString("mobile");
				email = rs.getString("email");
				entryDate = rs.getString("entry_date");
				grade = rs.getString("grade").charAt(0);
				mileage = rs.getInt("mileage");
				manager = rs.getString("manager");
				
				Member dto = new Member(memberId, memberPw, memberName, mobile, email, entryDate, grade, mileage, manager);
				tmp.add(dto);
			}
			return tmp;
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("����(��üȸ����ȸ ����) : " + e.getMessage());
		} finally {
			close(rs, stmt, conn);
		}
		return null;
	}
	
	
	// ��������ȸ(���̵�) : Member
	public Member selectOne(String memberId) {
		Member dto = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "select * from members where member_id = ?" ;
		
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, memberId);
			rs = stmt.executeQuery();
			
			String memberPw = null;
			String memberName = null;
			String mobile = null;
			String email = null;
			String entryDate = null;
			char grade = '\u0000';
			int mileage = 0;
			String manager = null;
			
			while(rs.next()) {
				memberId = rs.getString("member_id");
				memberPw = rs.getString("member_pw");
				memberName = rs.getString("member_name");
				mobile = rs.getString("mobile");
				email = rs.getString("email");
				entryDate = rs.getString("entry_date");
				grade = rs.getString("grade").charAt(0);
				mileage = rs.getInt("mileage");
				manager = rs.getString("manager");
				
			return new Member(memberId, memberPw, memberName, mobile, email, entryDate, grade, mileage, manager);
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("����(��üȸ����ȸ ����) : " + e.getMessage());
		} finally {
			close(rs, stmt, conn);
		}
		
		return null;
	}
	
	
	// ��޺� ��üȸ�� ��ȸ
	public ArrayList<Member> selectListGrade(String grade) {
		
		ArrayList<Member> tmp = new ArrayList<Member>();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "select * from members where grade =?" ;
		
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, grade);
			rs = stmt.executeQuery();
			
			String memberId = null;
			String memberPw = null;
			String memberName = null;
			String mobile = null;
			String email = null;
			String entryDate = null;
			int mileage = 0;
			String manager = null;
			
			
			while(rs.next()) {
				
				memberId = rs.getString("member_id");
				memberPw = rs.getString("member_pw");
				memberName = rs.getString("member_name");
				mobile = rs.getString("mobile");
				email = rs.getString("email");
				entryDate = rs.getString("entry_date");
				mileage = rs.getInt("mileage");
				manager = rs.getString("manager");
				
				Member dto = new Member(memberId, memberPw, memberName, mobile, email, entryDate, grade.charAt(0), mileage, manager);
				tmp.add(dto);
			}
			return tmp;
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("����(��޺� ȸ�� ��ȸ) : " + e.getMessage());
		} finally {
			close(rs, stmt, conn);
		}
		
		return null;
	}

	
	// �α���(���̵�, ��й�ȣ)
	public Member selectLogin(String memberId, String memberPw) {
		Member dto = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "select * from members where member_id = ? and member_pw = ?" ;
		
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, memberId);
			stmt.setString(2, memberPw);
			rs = stmt.executeQuery();
		
			String memberName = null;
			String mobile = null;
			String email = null;
			String entryDate = null;
			char grade = '\u0000';
			int mileage = 0;
			String manager = null;
			
			while(rs.next()) {
				memberId = rs.getString("member_id");
				memberPw = rs.getString("member_pw");
				memberName = rs.getString("member_name");
				mobile = rs.getString("mobile");
				email = rs.getString("email");
				entryDate = rs.getString("entry_date");
				grade = rs.getString("grade").charAt(0);
				mileage = rs.getInt("mileage");
				manager = rs.getString("manager");
				
			return new Member(memberId, memberPw, memberName, mobile, email, entryDate, grade, mileage, manager);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("����(�α��� ����) : " + e.getMessage());
		} finally {
			close(rs, stmt, conn);
		}
		
		return null;
	}
	
	
	// ȸ������
	public int insert(Member dto) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		String sql = "insert into members values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, dto.getMemberId());
			stmt.setString(2, dto.getMemberPw());
			stmt.setString(3, dto.getMemberName());
			stmt.setString(4, dto.getMobile());
			stmt.setString(5, dto.getEmail());
			stmt.setString(6, dto.getEntryDate());
			stmt.setString(7, dto.getGrade()+"");
			stmt.setInt(8, dto.getMileage());
			stmt.setString(9, dto.getManager());
			
			return stmt.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("����(ȸ����� ����) : " + e.getMessage());
		} finally {
			close(rs, stmt, conn);
		}
		return 0;
}
	

	// ȸ��Ż��
	public int delete(String memberId) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		String sql = "delete members where member_id = ?";
		
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, memberId);
			
			return stmt.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("����(ȸ��Ż�� ����) : " + e.getMessage());
		} finally {
			close(rs, stmt, conn);
		}
		return 0;
	}	
	
	
	// ȸ�� ��������
		/*
		 * ������ ����
		 * ����� ���氡���� �Ӽ�
		 * ��ȣ, �̸�, ����ó, �̸���
		 * 
		 * ������ ȸ�������� ����
		 * ��ȣ, �̸�, ����ó, �̸���, ������, ���, ���ϸ���, �����
		 */
		public int update(Member dto) {
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			
			StringBuilder sql = new StringBuilder();
			sql.append("update members set ");
			sql.append("member_pw = ?, member_name = ?, mobile = ?, email = ? ");
			sql.append("where member_id = ? ");
			
			try {
				conn = getConnection();
				stmt = conn.prepareStatement(sql.toString());
				stmt.setString(1, dto.getMemberPw());
				stmt.setString(2, dto.getMemberName());
				stmt.setString(3, dto.getMobile());
				stmt.setString(4, dto.getEmail());
				stmt.setString(5, dto.getMemberId());
				
				return stmt.executeUpdate();
			
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("����(������ ��ü���� ����) : " + e.getMessage());
			} finally {
				close(rs, stmt, conn);
			}
			return 0;
		}
		
}
